

$('.ui.dropdown')
    .dropdown();

$('.ui.sidebar')
    .sidebar();

$('.ui.accordion')
    .accordion();